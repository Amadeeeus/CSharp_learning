public interface ITask4
{
    // For Students
    // A
    public void ShowStudentsWhoGetGift(List<Students> students);
    
    // B
    public void ShowListWorkers(List<Students> students);

    // For Tasks
    // A
    public void SortList(List<string> strings);

    // B
    public void AddedSymbolForEachItem(List<string> strings);

    // C
    public int[] RemoveSymbolAndReturnInts(List<string> strings);

    // D
    public void SortListAndRemoveDuplicates(List<string> strings);
}