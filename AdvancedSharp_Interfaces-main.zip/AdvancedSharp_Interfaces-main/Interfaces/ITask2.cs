public interface ITask2
{
    // 2.1
    public List<T> GetUqniqueCollection<T>(List<T> values);

    // 2.3
    public int GetCountNumberTwoInRange(int n);

    // 2.4
    public bool CheckStringForSwap(string param1, string param2);

    // 2.5
    public string TryZipString(string str);

    // 2.6
    public char GetFirstAndMostRepeatChar(string str);

    // 2.7
    public bool CheckValidationBracketOnString(string str);

    // 2.8
    public string AddBracketsOnString(string str);

    // 2.9
    public string ConvertWhiteSpaceFromString(string str);

    // 2.10
    public int CountPairInArray(int[] ints);
}
