public interface ITask3<T>
{
    // 3.1
    public void ShowEmployees(List<T> employees);

    //3.2
    public IEnumerable<Employees> ShowEmployeesWithSalaryMoreOneHundredThousand(List<T> employees);

    //3.3
    public IEnumerable<Employees> ShowEmployeeWithMaxSalary(List<T> employees);

    //3.4
    public IEnumerable<IGrouping<string, Employees>>  GroupEmployeesByName(List<T> employees);

    //3.5
    public int ShowSumSalary(List<T> employees);

    //3.6
    public double ShowAverageSalary(List<T> employees);
}